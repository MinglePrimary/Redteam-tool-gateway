# INSTALL

1. Requires `js-beautify` node plugin installed in `$PATH`.
2. Requires `gofmt` installed in `$PATH`.
